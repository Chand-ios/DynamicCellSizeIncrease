//
//  ViewController.swift
//  DynamicCellSizeIncrease
//
//  Created by IBLEMAC LAP on 23/07/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl: UITableView!
    
    var array:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: - NOTE
            // Tableview cell heisght is dynamically increase.
            // steps1: Using autolayouts.
            // step2: set constraits in label in Leading, trailing, top, botom and only set height.
            // steps3: which label increase, that label Trailing and Height is editing and change (>) symbol.
            // tbl.estimatedRowHeight = 30
            // tbl.rowHeight = UITableView.automaticDimension.
        
        
        array = ["asdf","sfsdf sfdsdfsd f s ds sd sd sd g sdf f gds ds sd s d s ds sd  ds sd sd vsd vx vxc vx vxc vc vc vc vcx v cv cv cv cvd v dv dv dv sdv dfs ds fv dsv dsv dsf  d dsf v","sad f sf s fs fsd fs dfs df sdf sf s fas fas f  fa f as s","s fsad fs fasd f sdf s s sd  dv ds vsd vds vds v ds v dsv dsv ds  vds f df   f df sd fsd f sd f fd sf sad f asd sad f asf csd sd fs df sf df fd sf sfd adas da sd asd asd as das d asd asd asd as d asd as d asd asd as das da da s "]
        tbl.estimatedRowHeight = 30
        tbl.rowHeight = UITableView.automaticDimension
           
        // Do any additional setup after loading the view.
    }
    
   


}

extension ViewController: UITabBarDelegate,UITableViewDataSource{
    
    //MARK: - Tableview delegate methods.
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: [indexPath.row]) as! TblTableViewCell
        
        cell.labenName.numberOfLines = 0
        cell.labenName.text = array[indexPath.row]
        
        cell.labenName2.numberOfLines = 0
        cell.labenName2.text = array[indexPath.row]
        
        cell.labenName3.numberOfLines = 0
        cell.labenName3.text = array[indexPath.row]
        
        return cell
    }
    

    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 50
//    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableView.automaticDimension
//    }
    

    
}

