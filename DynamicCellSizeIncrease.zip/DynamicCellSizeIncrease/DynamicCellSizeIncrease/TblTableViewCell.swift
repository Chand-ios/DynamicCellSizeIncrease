//
//  TblTableViewCell.swift
//  DynamicCellSizeIncrease
//
//  Created by IBLEMAC LAP on 23/07/21.
//

import UIKit

class TblTableViewCell: UITableViewCell {

    @IBOutlet weak var labenName: UILabel!
    @IBOutlet weak var labenName2: UILabel!
    @IBOutlet weak var labenName3: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
